=== Maintenance ===
Contributors: WebFactory
Tags: maintenance, maintenance mode, maintenance page, coming soon, coming soon page
Requires at least: 4.4
Tested up to: 7.0
Stable tag: 4.30
Requires PHP: 5.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Great looking maintenance, coming soon & under construction pages. Put your site under maintenance in minutes.

== Description ==

<a href="https://wpmaintenancemode.com/">WP Maintenance</a> plugin allows the WordPress site administrator to close the website for maintenance, enable "503 Service temporarily unavailable”, set a temporary page with authorization, which can be edited via the plugin settings. Add your logo, background image, select the desired color and text - all with easy maintenance builder. Maintenance uses Bunny Fonts for EU GDPR compliance.

Need **pre-made themes** and over 8 million free images to build maintenance, coming soon & landing pages faster? Have a look at <a href="https://wpmaintenancemode.com/">WP Maintenance PRO</a> plugin.

Having problems with spam or bots? Try our free <a href="https://wordpress.org/plugins/advanced-google-recaptcha/">Advanced Google ReCaptcha</a> plugin. It's used on over 200,000 sites and provides great protection!

<h3>Features</h3>
<ul>
<li>over <a href="https://wpmaintenancemode.com/#themes">200 themes in the PRO version</li>
<li>Full-screen background (<a target="_blank" href="https://github.com/srobbin/jquery-backstretch">Backstretch</a>)</li>
<li>Blur background effect</li>
<li>Upload your own logo</li>
<li>Configurable colors: fonts, icons, background</li>
<li>Customize title, headline, text</li>
<li>User login on frontend</li>
<li>Admin bar status</li>
<li>503 error on/off</li>
<li>Google analytics support</li>
<li>Exclude selected pages from Maintenance mode</li>
<li>Support for all popular caching plugins</li>
<li><i>mtnc_load_maintenance_page_for_this_user</i> filter for modifying show sees the maintenance page</li>
</ul>

<h3>Support</h3>
If you have any problems, questions or recommendations about WP Maintenance please open a ticket in the <a href="https://wordpress.org/support/plugin/maintenance/">official support forum</a>. We answer all questions within hours!
Want to say "thank you"? Please leave a <a href="http://wordpress.org/support/view/plugin-reviews/maintenance?filter=5">review</a>.

<h3>GDPR Compatibility</h3>
We are not lawyers. Please do not take any of the following as legal advice.
If you don’t opt to use Bunny Fonts and don’t use Google Analytics then no resources are loaded or shared with 3rd parties. And nothing is tracked. Opting to use any of those services will result in data sharing/tracking as described in their terms of service.

Maintenance uses these 3rd party libs:

* Super simple WYSIWYG editor v0.9.0, MIT
* SweetAlert 2, github.com/Sweetalert2/Sweetalert2, MIT
* jscolor Color Picker, GNU GPL v3
* Ace Editor (Ajax.org Cloud9 Editor), BSD
* Web Font Loader, Apache 2 License

== Installation ==

Follow the usual routine;

1. Open WordPress admin, go to Plugins, click Add New
2. Enter "maintenance" in search and hit Enter
3. Locate the Maintenance plugin by searching for our mascot, click "Install Now"
4. Activate & open plugin's settings page located in the main WP admin menu

Or if needed, upload manually;

1. Download the plugin.
2. Unzip it and upload to _/wp-content/plugins/_
3. Open WordPress admin - Plugins and click "Activate" next to the plugin
4. Activate & open plugin's settings page located in the main WP admin menu


== Screenshots ==
1. Maintenance page with default design and layout
2. Log in form is built into the maintenance page
4. Maintenance plugin layout builder


== Frequently Asked Questions ==

= I have activated plugin and don’t see any changes, looks like plugin is not working. =

Try to check in different browser. If you a logged as WordPress user you see the website in normal mode.

= Will my site remain visible to search engines while maintenance mode is on? =

The site will not be visible to search engines only if "503 Service Temporarily Unavailable" option is enabled.

= Where can I find out the username and password to get to the site? =

You can use your "normal" WP administrator access or create a new user in WordPress dashboard - Users.

= I haven’t found an answer to my question, what should I do? =

Please post the question on the <a href="http://wordpress.org/support/plugin/maintenance">support forum</a>.

= How can I report security bugs? =

You can report security bugs through the Patchstack Vulnerability Disclosure Program. The Patchstack team help validate, triage and handle any security vulnerabilities. [Report a security vulnerability.](https://patchstack.com/database/vdp/maintenance)


== Changelog ==
= v4.30 =
- 2026/06/18
- complete rewrite, new options, new GUI
- drag&drop maintenance page builder

= v4.21 =
- 2026/04/02
- Minor fixes

= v4.20 =
- 2026/01/03
- Fixed Bunny Fonts getting loaded even for system fonts

= v4.19 =
- 2025/11/19
- WordPress 6.9 compatibility

= v4.18 =
- 2025/07/31
- improved mobile resposiveness

= v4.17 =
- 2025/01/22
- fixed Show some love option not saving

= v4.16 =
- 2025/01/10
- updated Google Analytics code
- added skip-lazy class to background image to fix Autoptimize compatibility

= v4.15 =
- 2024/10/22
- fixed bug with some options not being saved

= v4.14 =
- 2024/10/17
- excluded posts/pages not saving bug fix

= v4.13 =
- 2024/10/13
- minor security fixes

= v4.12 =
- 2024/06/07
- minor bug fixes

= v4.09 =
- 2024/06/03
- added Weglot support

= v4.08 =
- 2023/08/31
- fixed reset password URL changed if Maintenance is off

= v4.07 =
- 2022/05/06
- replaced Google Fonts with the privacy-oriented and GDPR compliant Bunny Fonts
- minor fix for image field

= v4.06 =
- 2022/05/06
- introduction of the PRO version

= v4.05 =
- 2022/01/04
- bug fix for retina image
- security fixes
- ad for our free WP Force SSL plugin

= v4.03 =
- 2021/07/18
- security fixes
- checked WP 5.8 compatibility

= v4.02 =
- 2021/03/06
- JS fixes on frontend
- Contact Form 7 conflict fix

= v4.01 =
- 2021/02/20
- added support for Cache Enabler plugin
- fixed a bug when background image isn't defined
- fixed issue on sites with large numbers of posts/pages/CPTs

= v4.0 =
- 2021/01/30
- added flyout menu
- added mtnc_load_maintenance_page_for_this_user filter

= v3.99 =
- 2021/01/13
- minor fixes
- removed promo for WP 301 Redirects

= v3.97 =
- 2020/10/02
- minor fixes
- added promo for WP 301 Redirects

= v3.96 =
- 2020/08/19
- "headers already sent" bug fixed

= v3.95 =
- 2020/08/14
- bug fixes for WP v5.5

= v3.90 =
- 2020/05/30
- bug fixes
- removed integration with Amelia Booking
- added support for WP Rocket Cache plugin
- fixed blur issue

= v3.85 =
- 2019/11/28
- bug fixes
- added integration with Amelia Booking
- added support for Hummingbird Cache plugin

= v3.80 =
- 2019/09/25
- numerous bug fixes
- added preview button
- 400,000 installations; 3,790,000 downloads
- for older changelog entries please refer to https://wpmaintenancemode.com/old-changelog.txt
